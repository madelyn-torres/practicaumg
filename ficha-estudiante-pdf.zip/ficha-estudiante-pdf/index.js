const PdfPrinter = require("pdfmake");
const fs = require("fs");
const path = require("path");

/* =========================
   FUNCIÓN PARA IMÁGENES
========================= */
function getBase64Image(filePath) {
  const file = fs.readFileSync(filePath);
  return file.toString("base64");
}

const logoBase64 = getBase64Image(path.join(__dirname, "logo.png"));
const fotoEstudianteBase64 = getBase64Image(
  path.join(__dirname, "estudiante.png")
);

/* =========================
   FUENTES
========================= */
const fonts = {
  Roboto: {
    normal: path.join(__dirname, "fonts/Roboto-Regular.ttf"),
    bold: path.join(__dirname, "fonts/Roboto-Medium.ttf"),
    italics: path.join(__dirname, "fonts/Roboto-Italic.ttf"),
    bolditalics: path.join(__dirname, "fonts/Roboto-MediumItalic.ttf"),
  },
};

/* =========================
   DATOS DEL ESTUDIANTE
========================= */
const estudiante = {
  nombres: "David Luis",
  apellidos: "Ajú Pitto",
  genero: "Masculino",
  fechaNacimiento: "13 de mayo de 2014",
  cui: "346838990101",
  codigoEstudiante: "L403FKU",
  direccion: "Aldea El Papayo",
  responsable: "Verónica Noelia Soto Barrios",
  relacion: "Abuela",
  correo: "correo@ejemplo.com",
  telefono: "5010-2952",
};

/* =========================
   ESTILOS
========================= */
const styles = {
  title: {
    fontSize: 13,
    bold: true,
    alignment: "center",
    margin: [0, 5, 0, 15],
    color: "#0A3D62",
  },
  section: {
    fontSize: 11,
    bold: true,
    margin: [0, 12, 0, 6],
    color: "#0A3D62",
  },
  label: {
    fontSize: 9,
    bold: true,
  },
  value: {
    fontSize: 10,
    margin: [0, 0, 0, 6],
  },
};

/* =========================
   DEFINICIÓN DEL PDF
========================= */
const docDefinition = {
  pageMargins: [40, 40, 40, 40],

  images: {
    logo: `data:image/png;base64,${logoBase64}`,
    foto: `data:image/png;base64,${fotoEstudianteBase64}`,
  },

  content: [
    {
      table: {
        widths: ["*"],
        body: [
          [
            {
              stack: [

                /* ENCABEZADO */
                {
                  columns: [
                    {
                      width: "*",
                      stack: [
                        {
                          text: "LICEO DEVCOM",
                          fontSize: 12,
                          bold: true,
                          color: "#0A3D62",
                        },
                        {
                          text: "CERTIFICADO DE REGISTRO ESTUDIANTIL",
                          style: "title",
                        },
                      ],
                    },
                    {
                      width: 80,
                      image: "logo",
                      fit: [60, 60],
                      alignment: "right",
                    },
                  ],
                },

                /* DATOS DEL ESTUDIANTE */
                { text: "Datos del Estudiante", style: "section" },

                {
                  columns: [
                    {
                      width: 80,
                      image: "foto",
                      fit: [70, 70],
                      alignment: "left",
                      margin: [0, 5, 10, 0]
                    },
                    {
                      width: "*",
                      columns: [
                        {
                          width: "50%",
                          stack: [
                            { text: "Nombres", style: "label" },
                            { text: estudiante.nombres, style: "value" },

                            { text: "Apellidos", style: "label" },
                            { text: estudiante.apellidos, style: "value" },

                            { text: "Género", style: "label" },
                            { text: estudiante.genero, style: "value" },
                          ],
                        },
                        {
                          width: "50%",
                          stack: [
                            { text: "Fecha de nacimiento", style: "label" },
                            { text: estudiante.fechaNacimiento, style: "value" },

                            { text: "CUI", style: "label" },
                            { text: estudiante.cui, style: "value" },

                            { text: "Código de estudiante", style: "label" },
                            { text: estudiante.codigoEstudiante, style: "value" },
                          ],
                        },
                      ],
                    }
                  ]
                },

                { text: "Lugar de Residencia", style: "section" },
                { text: "Dirección", style: "label" },
                { text: estudiante.direccion, style: "value" },

                { text: "Datos de Contacto", style: "section" },

                {
                  columns: [
                    {
                      width: "50%",
                      stack: [
                        { text: "Nombre del responsable", style: "label" },
                        { text: estudiante.responsable, style: "value" },

                        { text: "Relación", style: "label" },
                        { text: estudiante.relacion, style: "value" },
                      ],
                    },
                    {
                      width: "50%",
                      stack: [
                        { text: "Correo electrónico", style: "label" },
                        { text: estudiante.correo, style: "value" },

                        { text: "Teléfono", style: "label" },
                        { text: estudiante.telefono, style: "value" },
                      ],
                    },
                  ],
                },

                {
                  columns: [
                    {
                      width: "50%",
                      alignment: "center",
                      margin: [0, 30, 0, 0],
                      text: "_________________________\nFirma del responsable",
                      fontSize: 9,
                    },
                    {
                      width: "50%",
                      alignment: "center",
                      margin: [0, 30, 0, 0],
                      text: "_________________________\nSello de la institución",
                      fontSize: 9,
                    },
                  ],
                },
              ],
              border: [true, true, true, true],
              margin: [10, 10, 10, 10],
            },
          ],
        ],
      },
      layout: {
        hLineColor: () => "#0A3D62",
        vLineColor: () => "#0A3D62",
      },
    },
  ],

  styles,
};

/* =========================
   GENERAR PDF
========================= */
const printer = new PdfPrinter(fonts);
const pdfDoc = printer.createPdfKitDocument(docDefinition);

pdfDoc.pipe(fs.createWriteStream("certificado-estudiantil.pdf"));
pdfDoc.end();

console.log("PDF generado correctamente");